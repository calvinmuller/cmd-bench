<?php
/* ----- Copyright (c) CMDcentral 2012 ----- */

class Cmdcentral_PayD_Helper_Data extends Mage_Payment_Helper_Data {}
