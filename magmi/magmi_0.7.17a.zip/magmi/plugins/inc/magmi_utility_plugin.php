<?php
class Magmi_UtilityPlugin extends Magmi_Plugin
{
	public function runUtility()
	{
		//Put Running code 
	}
	
	public function getWarning()
	{
		return null;
	}
}