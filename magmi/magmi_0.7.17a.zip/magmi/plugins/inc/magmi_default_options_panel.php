<span>Plugin has no configurable parameters</span>
