<div class="plugin_description">
This plugin provides value mapping for csv values before they are handled by magmi
typically visibility & page_layout need mapping for magmi to process them correctly.
to change the mappings accordingly to your config,please edit the csv files located at :
<pre>[magmi_dir]/plugins/itemprocessors/genericmapper/mappings</pre>
the csv files have the following names [column_to_map].csv
</div>
